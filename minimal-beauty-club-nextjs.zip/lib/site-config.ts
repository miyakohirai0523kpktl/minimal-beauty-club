// 中央設定ファイル。ナビゲーションやサイト共通情報はここを編集すれば全ページに反映されます。
// 今後ページを追加する場合は navLinks に追記してください。

export const siteConfig = {
  name: "MINIMAL BEAUTY CLUB",
  shortName: "MBC",
  tagline: "美容オタクになりたいわけじゃない。でも、素肌には自信を持っていたい。",
  description:
    "MINIMAL BEAUTY CLUBは、忙しく働く女性のための「頑張りすぎない」美容ブランド。必要なことだけを、無理なく続ける。清潔感のある、健康的で自然な素肌を目指す人のためのミニマル美容メソッドを届けます。",
  url: "https://minimal-beauty-club.vercel.app",
  lineUrl: "https://liff.line.me/2011243353-nhgbgZxs",
  ogImage: "/images/og-image.jpg",
  // MINIMAL BEAUTY CHECK: 外部診断フォーム(Formrun / Judge など)のURLをここに設定すると
  // /check ページに自動でiframe埋め込みが表示されます。空文字の間はプレースホルダーを表示します。
  diagnosisEmbedUrl: "",
};

export type NavLink = {
  label: string;
  href: string;
};

export const navLinks: NavLink[] = [
  { label: "HOME", href: "/" },
  { label: "ABOUT", href: "/about" },
  { label: "METHOD", href: "/method" },
  { label: "MINIMAL BEAUTY CHECK", href: "/check" },
  { label: "CONTACT / LINE", href: "/contact" },
];

export const footerLinks: NavLink[] = [
  { label: "HOME", href: "/" },
  { label: "ABOUT", href: "/about" },
  { label: "METHOD", href: "/method" },
  { label: "MINIMAL BEAUTY CHECK", href: "/check" },
  { label: "CONTACT / LINE", href: "/contact" },
];
