# MINIMAL BEAUTY CLUB

Next.js (App Router) + React + Tailwind CSS で構築した MINIMAL BEAUTY CLUB のブランドサイトです。

## 開発

```bash
npm install
npm run dev
```

http://localhost:3000 で確認できます。

## ビルド確認

```bash
npm run build
```

## Vercelへのデプロイ

1. このフォルダをGitリポジトリにする(GitHub / GitLab / Bitbucketなど)
   ```bash
   git init
   git add .
   git commit -m "init: MINIMAL BEAUTY CLUB site"
   git remote add origin <あなたのリポジトリURL>
   git push -u origin main
   ```
2. https://vercel.com にログインし、「Add New... → Project」から上記リポジトリをImport
3. Framework Preset は自動で "Next.js" が検出されます。設定変更不要でそのままDeployでOKです
4. デプロイ完了後に発行されるURLを、`lib/site-config.ts` の `url` に反映すると、OGP・サイトマップ等が正しく動作します

## ファイル構成

```
app/
  layout.tsx          共通レイアウト(Nav・Footer・フォント・既定SEO)
  page.tsx            HOME
  about/page.tsx       ABOUT
  method/page.tsx       METHOD
  check/page.tsx        MINIMAL BEAUTY CHECK(診断ページ)
  contact/page.tsx      CONTACT / LINE
  sitemap.ts / robots.ts   SEO基本設定
components/
  Nav.tsx / Footer.tsx       共通ナビゲーション・フッター
  Button.tsx / LineButton.tsx    ボタン(コンポーネント化済み)
  Container.tsx / SectionHeading.tsx / ValueCard.tsx   汎用UIパーツ
  DiagnosisEmbed.tsx     診断フォーム埋め込み用(Formrun/Judge対応)
lib/
  site-config.ts       サイト共通設定(ナビゲーション・LINE URL・診断埋め込みURLなど)
```

## 今後の拡張について

- **診断機能**: `lib/site-config.ts` の `diagnosisEmbedUrl` にFormrunやJudgeの埋め込みURLを設定すると、
  `/check` ページに自動でiframe表示されます(`components/DiagnosisEmbed.tsx`)。
- **記事・イベント・商品紹介の追加**: `app/` 配下に新しいフォルダ(例: `app/articles/`, `app/events/`)を作成し、
  `page.tsx` を追加するだけでページが増やせます。共通ナビゲーションに載せたい場合は
  `lib/site-config.ts` の `navLinks` / `footerLinks` に追記してください。
- **ボタン・カード**などのUIは `components/` 内で共通化しているため、新しいページでも再利用できます。
