import type { Metadata } from "next";
import Container from "@/components/Container";
import SectionHeading from "@/components/SectionHeading";
import LineButton from "@/components/LineButton";
import Button from "@/components/Button";

export const metadata: Metadata = {
  title: "METHOD",
  description:
    "MBCが考えるミニマル美容メソッド。外側のケア、内側のケア、習慣という3つの視点から、必要なことだけを無理なく続ける考え方をご紹介します。",
};

const outer = [
  "肌に必要な工程だけに絞り、ひとつひとつの質にこだわる",
  "「増やす」のではなく「削ぎ落とす」視点でアイテムを選ぶ",
  "自分の肌状態に合わせて、季節や年齢による変化にも対応する",
];

const inner = [
  "肌は内側からもつくられるという前提を持つ",
  "食事、睡眠、巡りなど、土台となる生活習慣を見直す",
  "一時的な流行ではなく、続けやすい範囲で整える",
];

const habit = [
  "完璧を目指さず、忙しい日や疲れた日にも続けられるように設計する",
  "小さな習慣を積み重ね、無理のないペースで変化を待つ",
  "公式LINEなどでの伴走を通じて、ひとりで抱え込まない",
];

function MethodList({ items }: { items: string[] }) {
  return (
    <ul className="mt-6 space-y-4 border-t border-line pt-6">
      {items.map((item) => (
        <li key={item} className="flex gap-4 text-[14.5px] leading-7 text-ink-soft">
          <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-sage-500" />
          <span>{item}</span>
        </li>
      ))}
    </ul>
  );
}

export default function MethodPage() {
  return (
    <>
      <section className="section pt-16 md:pt-24">
        <Container>
          <p className="kicker">METHOD</p>
          <h1 className="balance mt-6 max-w-2xl font-serif text-3xl leading-[1.6] text-ink md:text-4xl">
            MBCが考える、ミニマル美容。
          </h1>
          <p className="mt-7 max-w-xl text-[15px] leading-8 text-ink-soft">
            必要なことだけを、無理なく続ける。MINIMAL BEAUTY
            METHODは「外側のケア」「内側のケア」「習慣」という3つの視点で構成されています。
          </p>
        </Container>
      </section>

      <section className="section border-t border-line bg-cream">
        <Container className="grid gap-14 md:grid-cols-3 md:gap-10">
          <div>
            <SectionHeading kicker="01 ／ OUTER CARE" title="外側のケア" />
            <MethodList items={outer} />
          </div>
          <div>
            <SectionHeading kicker="02 ／ INNER CARE" title="内側のケア" />
            <MethodList items={inner} />
          </div>
          <div>
            <SectionHeading kicker="03 ／ HABIT" title="習慣" />
            <MethodList items={habit} />
          </div>
        </Container>
      </section>

      <section className="section border-t border-line">
        <Container>
          <SectionHeading
            kicker="OUR PHILOSOPHY"
            title="必要なことだけを、無理なく続ける。"
            lead="美容は特別なことではなく、日々の暮らしの一部であるべきだと考えています。頑張って続けるものではなく、気づけば続いている。そんな仕組みをつくることが、MINIMAL BEAUTY METHODの目的です。"
          />
        </Container>
      </section>

      <section className="section border-t border-line bg-sage-700 text-paper">
        <Container className="flex flex-col items-start gap-8 md:flex-row md:items-center md:justify-between">
          <div className="max-w-xl">
            <p className="kicker !text-sage-200">MINIMAL BEAUTY CHECK</p>
            <h2 className="balance mt-4 font-serif text-2xl leading-relaxed md:text-3xl">
              まずは、自分の肌を知ることから。
            </h2>
          </div>
          <Button
            href="/check"
            variant="outline"
            className="!border-paper !text-paper hover:!bg-paper hover:!text-ink shrink-0"
          >
            診断をはじめる
          </Button>
        </Container>
      </section>

      <section className="section border-t border-line text-center">
        <Container>
          <p className="kicker mx-auto">SUPPORT</p>
          <h2 className="balance mx-auto mt-4 max-w-lg font-serif text-2xl leading-relaxed text-ink md:text-3xl">
            公式LINEで、あなたの美容習慣にそっと伴走します。
          </h2>
          <div className="mt-10 flex justify-center">
            <LineButton />
          </div>
        </Container>
      </section>
    </>
  );
}
