import type { Metadata } from "next";
import Container from "@/components/Container";
import SectionHeading from "@/components/SectionHeading";
import DiagnosisEmbed from "@/components/DiagnosisEmbed";

export const metadata: Metadata = {
  title: "MINIMAL BEAUTY CHECK",
  description:
    "約3分のセルフチェックで、今の肌状態と美容習慣、自分に合った美容との向き合い方を知ることができます。MINIMAL BEAUTY CLUBの診断ページです。",
};

const steps = [
  { title: "質問に答える", desc: "肌の状態や生活習慣に関する質問に答えます" },
  { title: "傾向を知る", desc: "あなたの肌タイプと今の美容習慣の傾向がわかります" },
  { title: "次の一歩へ", desc: "本当に必要なケアと、続けやすい習慣のヒントを届けます" },
];

export default function CheckPage() {
  return (
    <>
      <section className="section pt-16 md:pt-24">
        <Container>
          <p className="kicker">MINIMAL BEAUTY CHECK</p>
          <h1 className="balance mt-6 max-w-2xl font-serif text-3xl leading-[1.6] text-ink md:text-4xl">
            まずは、自分の肌を知ることから。
          </h1>
          <p className="mt-7 max-w-xl text-[15px] leading-8 text-ink-soft">
            約3分のセルフチェックで、今の肌状態や美容習慣、自分に合った美容との向き合い方を知ることができます。
          </p>
        </Container>
      </section>

      <section className="section border-t border-line bg-cream">
        <Container>
          <div className="grid gap-8 md:grid-cols-3">
            {steps.map((s, i) => (
              <div key={s.title} className="border-t border-line pt-5">
                <span className="font-serif text-xs tracking-widest2 text-sage-500">
                  0{i + 1}
                </span>
                <h3 className="mt-3 font-serif text-lg text-ink">{s.title}</h3>
                <p className="mt-2 text-[14px] leading-7 text-ink-soft">{s.desc}</p>
              </div>
            ))}
          </div>
        </Container>
      </section>

      <section className="section border-t border-line">
        <Container>
          <SectionHeading kicker="START" title="診断スタート" align="center" />
          <div className="mt-10">
            <DiagnosisEmbed />
          </div>
        </Container>
      </section>
    </>
  );
}
