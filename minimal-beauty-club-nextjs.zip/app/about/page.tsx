import type { Metadata } from "next";
import Container from "@/components/Container";
import SectionHeading from "@/components/SectionHeading";
import ValueCard from "@/components/ValueCard";
import LineButton from "@/components/LineButton";
import Button from "@/components/Button";

export const metadata: Metadata = {
  title: "ABOUT",
  description:
    "MINIMAL BEAUTY CLUBとは何か、なぜこのブランドを作ったのか、大切にしている考え方をご紹介します。忙しく働く女性のための、頑張りすぎない美容ブランドです。",
};

const values = [
  {
    index: "01",
    title: "答えは、増やすことにはない",
    description:
      "新しいアイテムを足すほど、迷いも増えていく。私たちが届けたいのは「もっと」ではなく、あなたに合った「これだけでいい」という納得感です。",
  },
  {
    index: "02",
    title: "完璧な肌より、続けられる習慣",
    description:
      "一時的にきれいになることより、無理なく続けられること。忙しい毎日の中でも続けられる仕組みこそ、結果的に肌を変えていくと考えています。",
  },
  {
    index: "03",
    title: "情報に振り回されない",
    description:
      "SNSや口コミの情報に流されるのではなく、自分の肌の仕組みを理解し、自分で選べるようになること。知ることは、迷わなくなる近道です。",
  },
  {
    index: "04",
    title: "美容は人生の土台、主役ではない",
    description:
      "肌への安心感は自信につながり、その自信が仕事や趣味、大切な人との時間を豊かにする。美容はそのための土台だと考えています。",
  },
];

export default function AboutPage() {
  return (
    <>
      <section className="section pt-16 md:pt-24">
        <Container>
          <p className="kicker">ABOUT</p>
          <h1 className="balance mt-6 max-w-2xl font-serif text-3xl leading-[1.6] text-ink md:text-4xl">
            MINIMAL BEAUTY CLUBとは。
          </h1>
          <p className="mt-7 max-w-xl text-[15px] leading-8 text-ink-soft">
            忙しく働く女性のための、「頑張りすぎない」美容ブランドです。美容に多くの時間やお金をかけるのではなく、自分に本当に必要なことを知り、シンプルに、無理なく続けられる美容習慣を届けています。
          </p>
        </Container>
      </section>

      <section className="section border-t border-line bg-cream">
        <Container>
          <SectionHeading
            kicker="WHY WE STARTED"
            title="なぜ、このブランドを作ったのか。"
          />
          <div className="mt-8 max-w-2xl space-y-6 text-[15px] leading-8 text-ink-soft">
            <p>
              肌に悩んでいた時期、たくさんの情報やアイテムを試しては、何が自分に合っているのかわからなくなる。そんな経験がありました。
            </p>
            <p>
              時間をかけて気づいたのは、肌がきれいになることそのものがゴールではないということ。本当に変わったのは、肌を気にする時間や不安が減り、自分らしく過ごせるようになったことでした。
            </p>
            <p>
              その実感があったから、「もっと美容を頑張ること」をすすめたいとは思いません。20代後半から30代、仕事も日々の生活も大切にしたいあなたに、必要なことだけを、無理なく続けられる美容を届けたい。MINIMAL
              BEAUTY CLUBは、そんな想いから生まれました。
            </p>
          </div>
        </Container>
      </section>

      <section className="section border-t border-line">
        <Container>
          <SectionHeading
            kicker="OUR VALUES"
            title="大切にしている考え方。"
          />
          <div className="mt-12 grid gap-4 md:grid-cols-2">
            {values.map((v) => (
              <ValueCard key={v.index} index={v.index} title={v.title} description={v.description} />
            ))}
          </div>
        </Container>
      </section>

      <section className="section border-t border-line bg-sage-700 text-paper">
        <Container className="flex flex-col items-start gap-8 md:flex-row md:items-center md:justify-between">
          <div className="max-w-xl">
            <p className="kicker !text-sage-200">METHOD</p>
            <h2 className="balance mt-4 font-serif text-2xl leading-relaxed md:text-3xl">
              考え方を、具体的な習慣に落とし込む。
            </h2>
          </div>
          <Button
            href="/method"
            variant="outline"
            className="!border-paper !text-paper hover:!bg-paper hover:!text-ink shrink-0"
          >
            METHODを見る
          </Button>
        </Container>
      </section>

      <section className="section border-t border-line text-center">
        <Container>
          <p className="kicker mx-auto">SUPPORT</p>
          <h2 className="balance mx-auto mt-4 max-w-lg font-serif text-2xl leading-relaxed text-ink md:text-3xl">
            公式LINEで、あなたの美容習慣にそっと伴走します。
          </h2>
          <div className="mt-10 flex justify-center">
            <LineButton />
          </div>
        </Container>
      </section>
    </>
  );
}
