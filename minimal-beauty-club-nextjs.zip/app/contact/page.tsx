import type { Metadata } from "next";
import Container from "@/components/Container";
import LineButton from "@/components/LineButton";

export const metadata: Metadata = {
  title: "CONTACT / LINE",
  description:
    "MINIMAL BEAUTY CLUBへのお問い合わせ、ご相談は公式LINEから承っています。友だち追加のうえ、お気軽にメッセージをお送りください。",
};

export default function ContactPage() {
  return (
    <section className="section pt-16 text-center md:pt-24">
      <Container>
        <p className="kicker mx-auto">CONTACT / LINE</p>
        <h1 className="balance mx-auto mt-6 max-w-xl font-serif text-3xl leading-[1.6] text-ink md:text-4xl">
          公式LINEで、あなたの美容習慣にそっと伴走します。
        </h1>
        <p className="mx-auto mt-7 max-w-md text-[15px] leading-8 text-ink-soft">
          ご相談やお問い合わせは、公式LINEから承っています。友だち追加のうえ、お気軽にメッセージをお送りください。
        </p>
        <div className="mt-10 flex justify-center">
          <LineButton />
        </div>
      </Container>
    </section>
  );
}
