import type { Metadata } from "next";
import Link from "next/link";
import Container from "@/components/Container";
import SectionHeading from "@/components/SectionHeading";
import Button from "@/components/Button";
import LineButton from "@/components/LineButton";
import ValueCard from "@/components/ValueCard";

export const metadata: Metadata = {
  title: "MINIMAL BEAUTY CLUB ｜ 頑張りすぎない、働く女性のための美容",
  description:
    "MINIMAL BEAUTY CLUBは、20代後半〜30代の忙しく働く女性のための美容ブランド。美容オタクになりたいわけじゃない、でも素肌には自信を持っていたい人へ、必要なことだけを、無理なく続けるミニマル美容メソッドを届けます。",
};

const skinPoints = [
  { char: "う", name: "うるおい", desc: "乾燥を感じない、みずみずしい肌" },
  { char: "な", name: "なめらかさ", desc: "触れたときに整っている肌" },
  { char: "は", name: "はり", desc: "いきいきとした弾力のある肌" },
  { char: "け", name: "けっしょく", desc: "健康的で自然な血色感のある肌" },
  { char: "つ", name: "つや", desc: "光を受けて自然に輝く肌" },
];

const methodPreview = [
  {
    index: "01",
    title: "外側のケア",
    description: "肌に必要な工程だけに絞り、質にこだわる。増やさない、削ぎ落とすケア。",
  },
  {
    index: "02",
    title: "内側のケア",
    description: "肌は内側からもつくられる。食事や巡りなど、土台を整える視点を持つ。",
  },
  {
    index: "03",
    title: "習慣",
    description: "忙しい毎日でも続けられる、無理のないペースで積み重ねる。",
  },
];

export default function HomePage() {
  return (
    <>
      {/* ---- ファーストビュー ---- */}
      <section className="section pt-20 md:pt-28">
        <Container>
          <p className="kicker">MINIMAL BEAUTY CLUB</p>
          <h1 className="balance mt-6 max-w-3xl font-serif text-3xl leading-[1.6] text-ink md:text-5xl">
            美容オタクになりたいわけじゃない。でも、素肌には自信を持っていたい。
          </h1>
          <p className="mt-7 max-w-xl text-[15px] leading-8 text-ink-soft md:text-base">
            仕事に、時間に追われる毎日でも、素肌にちゃんと自信を持てるように。MINIMAL
            BEAUTY CLUBは、忙しく働く女性のための「頑張りすぎない」美容ブランドです。
          </p>
          <div className="mt-10 flex flex-wrap gap-4">
            <Button href="/check">MINIMAL BEAUTY CHECKを受けてみる</Button>
            <Button href="/about" variant="outline">
              ブランドについて知る
            </Button>
          </div>
        </Container>
      </section>

      {/* ---- コンセプト ---- */}
      <section className="section border-t border-line">
        <Container>
          <SectionHeading
            kicker="CONCEPT"
            title="必要なことだけを、無理なく続ける。"
            lead="美容に多くの時間やお金をかけることが、正解ではありません。自分の肌に本当に必要なことを知り、シンプルに、無理なく続けられること。それが、忙しい毎日を送るあなたにとって一番効率のいい美容だと考えています。"
          />
          <div className="mt-10 flex flex-wrap gap-3">
            {["Minimal", "Clean", "Healthy", "Smart", "Natural", "Efficient"].map(
              (word) => (
                <span
                  key={word}
                  className="rounded-full border border-line px-5 py-2 text-xs tracking-wider2 text-ink-soft"
                >
                  {word}
                </span>
              )
            )}
          </div>
        </Container>
      </section>

      {/* ---- 美容を頑張りすぎていませんか ---- */}
      <section className="section border-t border-line bg-cream">
        <Container>
          <SectionHeading
            kicker="QUESTION"
            title="美容を、頑張りすぎていませんか？"
          />
          <ul className="mt-10 grid gap-0 border-t border-line md:grid-cols-2 md:gap-x-10">
            {[
              "情報が多すぎて、結局何が自分に合っているのかわからない",
              "口コミやSNSで見て、気になったものをとりあえず試している",
              "特に不満はないけれど、肌が変わっている実感はあまりない",
              "美容に、これ以上時間もお金もかけたくない",
            ].map((text) => (
              <li
                key={text}
                className="border-b border-line py-5 text-[14.5px] leading-7 text-ink-soft md:border-b-0 md:border-t"
              >
                {text}
              </li>
            ))}
          </ul>
          <p className="mt-10 max-w-xl text-[15px] leading-8 text-ink-soft">
            ひとつでも当てはまったなら、美容の「量」ではなく「選び方」を見直すタイミングかもしれません。
          </p>
        </Container>
      </section>

      {/* ---- MINIMAL BEAUTY CHECKへの導線 ---- */}
      <section className="section border-t border-line">
        <Container className="flex flex-col items-start gap-8 md:flex-row md:items-center md:justify-between">
          <SectionHeading
            kicker="MINIMAL BEAUTY CHECK"
            title="まずは、自分の肌を知ることから。"
            lead="約3分のセルフチェックで、今のあなたの肌状態と、本当に必要な美容習慣が見えてきます。"
          />
          <Button href="/check" className="shrink-0">
            診断をはじめる
          </Button>
        </Container>
      </section>

      {/* ---- MBCが考える「素肌が美しい」 ---- */}
      <section className="section border-t border-line bg-cream">
        <Container>
          <SectionHeading
            kicker="STANDARD"
            title="MBCが考える「素肌が美しい」。"
            lead="派手さや流行ではなく、健康的でナチュラルな状態こそ美しい。私たちは、5つの視点で素肌を捉えています。"
          />
          <div className="mt-12 grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-5">
            {skinPoints.map((p) => (
              <div
                key={p.char}
                className="border border-line bg-white/60 p-6 text-center"
              >
                <div className="font-serif text-2xl text-sage-600">{p.char}</div>
                <div className="mt-2 text-xs tracking-wider2 text-ink">{p.name}</div>
                <p className="mt-3 text-[12.5px] leading-6 text-ink-soft">{p.desc}</p>
              </div>
            ))}
          </div>
        </Container>
      </section>

      {/* ---- MINIMAL BEAUTY METHOD ---- */}
      <section className="section border-t border-line">
        <Container>
          <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
            <SectionHeading
              kicker="MINIMAL BEAUTY METHOD"
              title="外側と内側、そして習慣。3つの視点でつくる。"
            />
            <Link
              href="/method"
              className="text-xs tracking-wider2 text-ink-soft underline underline-offset-4 hover:text-ink"
            >
              METHODの詳細を見る →
            </Link>
          </div>
          <div className="mt-12 grid gap-4 md:grid-cols-3">
            {methodPreview.map((m) => (
              <ValueCard key={m.index} index={m.index} title={m.title} description={m.description} />
            ))}
          </div>
        </Container>
      </section>

      {/* ---- ABOUTへの導線 ---- */}
      <section className="section border-t border-line bg-sage-700 text-paper">
        <Container className="flex flex-col items-start gap-8 md:flex-row md:items-center md:justify-between">
          <div className="max-w-xl">
            <p className="kicker !text-sage-200">ABOUT</p>
            <h2 className="balance mt-4 font-serif text-2xl leading-relaxed md:text-3xl">
              なぜMINIMAL BEAUTY CLUBを作ったのか。
            </h2>
            <p className="mt-5 text-[14.5px] leading-7 text-sage-50/90">
              ブランドに込めた想いと、大切にしている考え方をご紹介します。
            </p>
          </div>
          <Button href="/about" variant="outline" className="!border-paper !text-paper hover:!bg-paper hover:!text-ink shrink-0">
            ABOUTを見る
          </Button>
        </Container>
      </section>

      {/* ---- 公式LINEへの導線 ---- */}
      <section className="section border-t border-line">
        <Container className="text-center">
          <p className="kicker mx-auto">SUPPORT</p>
          <h2 className="balance mx-auto mt-4 max-w-lg font-serif text-2xl leading-relaxed text-ink md:text-3xl">
            公式LINEで、あなたの美容習慣にそっと伴走します。
          </h2>
          <div className="mt-10 flex justify-center">
            <LineButton />
          </div>
        </Container>
      </section>
    </>
  );
}
