import Button from "./Button";
import { siteConfig } from "@/lib/site-config";

type LineButtonProps = {
  label?: string;
  variant?: "primary" | "outline" | "ghost";
  className?: string;
};

export default function LineButton({
  label = "公式LINEを友だち追加する",
  variant = "primary",
  className = "",
}: LineButtonProps) {
  return (
    <Button href={siteConfig.lineUrl} external variant={variant} className={className}>
      {label}
    </Button>
  );
}
