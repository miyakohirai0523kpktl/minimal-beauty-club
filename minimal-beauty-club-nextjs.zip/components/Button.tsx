import Link from "next/link";
import type { ReactNode } from "react";

type ButtonVariant = "primary" | "outline" | "ghost";

type ButtonProps = {
  href: string;
  children: ReactNode;
  variant?: ButtonVariant;
  external?: boolean;
  className?: string;
};

const base =
  "inline-flex items-center justify-center gap-2 rounded-full px-8 py-4 text-sm tracking-wider2 transition-colors duration-300 whitespace-nowrap";

const variants: Record<ButtonVariant, string> = {
  primary: "bg-ink text-paper hover:bg-sage-700",
  outline: "border border-ink text-ink hover:bg-ink hover:text-paper",
  ghost: "text-ink-soft hover:text-ink underline underline-offset-4",
};

export default function Button({
  href,
  children,
  variant = "primary",
  external = false,
  className = "",
}: ButtonProps) {
  const classes = `${base} ${variants[variant]} ${className}`;

  if (external) {
    return (
      <a href={href} target="_blank" rel="noopener noreferrer" className={classes}>
        {children}
      </a>
    );
  }

  return (
    <Link href={href} className={classes}>
      {children}
    </Link>
  );
}
