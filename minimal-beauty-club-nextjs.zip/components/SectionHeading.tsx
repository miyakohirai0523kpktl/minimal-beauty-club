type SectionHeadingProps = {
  kicker?: string;
  title: string;
  lead?: string;
  align?: "left" | "center";
};

export default function SectionHeading({
  kicker,
  title,
  lead,
  align = "left",
}: SectionHeadingProps) {
  const alignment = align === "center" ? "text-center mx-auto" : "text-left";

  return (
    <div className={`max-w-2xl ${alignment}`}>
      {kicker && <p className="kicker mb-4">{kicker}</p>}
      <h2 className="balance font-serif text-2xl leading-relaxed text-ink md:text-4xl">
        {title}
      </h2>
      {lead && (
        <p className="mt-5 text-[15px] leading-8 text-ink-soft md:text-base">
          {lead}
        </p>
      )}
    </div>
  );
}
