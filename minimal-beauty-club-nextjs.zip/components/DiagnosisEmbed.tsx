"use client";

import { siteConfig } from "@/lib/site-config";
import LineButton from "./LineButton";

/**
 * MINIMAL BEAUTY CHECK 診断エリア。
 *
 * 実装方法:
 * 1. Formrun / Judge などの外部診断ツールで診断フォームを作成する
 * 2. lib/site-config.ts の diagnosisEmbedUrl に埋め込み用URLを設定する
 * 3. このコンポーネントが自動的にiframeで診断フォームを表示する
 *
 * 診断結果から公式LINEへ誘導する場合は、外部ツール側の完了画面/リダイレクト先に
 * siteConfig.lineUrl を設定してください。
 */
export default function DiagnosisEmbed() {
  if (siteConfig.diagnosisEmbedUrl) {
    return (
      <div className="overflow-hidden rounded-md border border-line bg-white">
        <iframe
          src={siteConfig.diagnosisEmbedUrl}
          title="MINIMAL BEAUTY CHECK"
          className="h-[720px] w-full"
        />
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center gap-6 border border-dashed border-line bg-cream px-8 py-16 text-center">
      <p className="text-xs tracking-wider2 text-ink-soft">
        MINIMAL BEAUTY CHECK ／ 準備中
      </p>
      <p className="max-w-md text-[14.5px] leading-7 text-ink-soft">
        診断機能は現在準備中です。公開までの間は、公式LINEからお気軽にご相談ください。
      </p>
      <LineButton label="公式LINEで相談する" />
    </div>
  );
}
