import Link from "next/link";
import { footerLinks, siteConfig } from "@/lib/site-config";

export default function Footer() {
  return (
    <footer className="border-t border-line bg-cream">
      <div className="mx-auto max-w-content px-6 py-14 md:px-10">
        <div className="flex flex-col gap-10 md:flex-row md:justify-between">
          <div className="max-w-sm">
            <p className="font-serif text-sm tracking-widest2 text-ink">
              {siteConfig.name}
            </p>
            <p className="mt-4 text-[13px] leading-7 text-ink-soft">
              {siteConfig.tagline}
            </p>
          </div>

          <nav className="grid grid-cols-2 gap-x-10 gap-y-3 md:flex md:gap-10">
            {footerLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="text-xs tracking-wider2 text-ink-soft hover:text-ink"
              >
                {link.label}
              </Link>
            ))}
          </nav>
        </div>

        <div className="mt-12 flex flex-col gap-2 border-t border-line pt-6 text-[11px] tracking-wider2 text-ink-soft md:flex-row md:justify-between">
          <p>© {new Date().getFullYear()} {siteConfig.name}</p>
          <p>MINIMAL / CLEAN / HEALTHY / SMART / NATURAL / EFFICIENT</p>
        </div>
      </div>
    </footer>
  );
}
