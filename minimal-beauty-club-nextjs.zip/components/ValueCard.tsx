type ValueCardProps = {
  index?: string;
  title: string;
  description: string;
};

export default function ValueCard({ index, title, description }: ValueCardProps) {
  return (
    <div className="border border-line bg-white/60 p-8 transition-colors hover:border-sage-300">
      {index && (
        <span className="mb-4 block font-serif text-xs tracking-widest2 text-sage-500">
          {index}
        </span>
      )}
      <h3 className="font-serif text-lg text-ink">{title}</h3>
      <p className="mt-3 text-[14.5px] leading-7 text-ink-soft">{description}</p>
    </div>
  );
}
