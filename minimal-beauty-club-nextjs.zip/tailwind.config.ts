import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./lib/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        paper: "#FAFAF7",
        ink: "#1F211D",
        "ink-soft": "#5C5F56",
        sage: {
          50: "#F3F6EF",
          100: "#E4EBDB",
          200: "#CBD8B9",
          300: "#AEC095",
          400: "#8FA974",
          500: "#71905A",
          600: "#5A7546",
          700: "#485E39",
        },
        line: "#E4E3DC",
        cream: "#F2F0E6",
      },
      fontFamily: {
        sans: [
          "var(--font-zen)",
          "Hiragino Sans",
          "Noto Sans JP",
          "sans-serif",
        ],
        serif: ["var(--font-shippori)", "serif"],
      },
      maxWidth: {
        content: "1120px",
      },
      letterSpacing: {
        wider2: "0.08em",
        widest2: "0.2em",
      },
    },
  },
  plugins: [],
};
export default config;
